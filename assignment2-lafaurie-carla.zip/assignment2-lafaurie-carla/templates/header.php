<?php   

include('includes/functions.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" media="all" href="css/style.css" />
  <title>My Site of Quotes</title>
</head>

<body>
    <div id="container">
    <h1> <a href="index.php">My Site of Quotes</a></h1>

</div>
<footer id="footer"> content &copy; <?php echo date('Y'); ?> </footer>
</body>
</html>


        
  