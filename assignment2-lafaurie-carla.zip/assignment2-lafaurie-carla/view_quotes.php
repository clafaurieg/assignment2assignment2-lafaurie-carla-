<?php


// view Quotes 

include('templates/header.php'); 

echo "<h2> View Quotes </h2>"; 

// restrict access 

if(!is_administrator()){ 
    echo"<h2>Access Denied!</h2>"; 
    echo "<p class='error'>You don't have enough access to this page.</p>"; 
    
// include footer template 

    include('templates/footer.php'); 

    exit(); 
}

// Define query 

$query = "SELECT id, quote, source, favorite FROM quotes ORDER BY date_entered DESC"; 

// run the query 

if($result = mysqli_query($dbc, $query)){ 

    // retrieve the returned records

    while($row = mysqli_fetch_array($result)) { 
        //echo the quote 
        echo "<div><blockquote>{$row['quote']}</blockquote>--{$row['source']}\n"; 


        // is this favorite 

        if($row['favorite'] == 1){ 
          echo "<strong>Favorite!</strong>";  
        }

        //add admin links 
        echo"<p>Quote Admin: <a href=\"edit_quote.php?id={$row['id']}\">Edit</a>
        <a href=\"delete_quote.php?id={$row['id']}\">Delete</a></p></div>";    
    
    }//while loop end 
}else{ 
    echo"<p class='error'>could not get the data becasue: " . mysqli_error($dbc) . "</p>"; 
}

mysqli_close($dbc); 

include('templates/footer.php'); 

?> 


