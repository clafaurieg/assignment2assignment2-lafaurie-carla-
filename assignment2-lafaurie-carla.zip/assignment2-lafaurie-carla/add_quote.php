<?php 
// Add Quotes 

include('templates/header.php'); 

echo "<h2> Please Add a quote</h2>"; 


if(!is_administrator()){ 
    echo"<h2>Access Denied!</h2>"; 
    echo "<p class='error'>You don't have enough access to this page.</p>"; 
    

    include('templates/footer.php'); 

    exit(); 
}


if($_SERVER['REQUEST_METHOD'] == "POST"){ 
    if(!empty($_POST['quote']) && !empty($_POST['source'])) { 
        $quote = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['quote']))); 
        $source = mysqli_real_escape_string($dbc, trim(strip_tags($_POST['source'])));

        if(isset($_POST['favorite'])){ 
            $favorite = 1; 
        }else{ 
            $favorite = 0; 
        }

        $query = "INSERT INTO quotes (quote,source,favorite) VALUES('$quote', '$source', $favorite)"; 
            mysqli_query($dbc, $query); 


        if(mysqli_affected_rows($dbc) == 1){ 

            echo "<p>Your quote has been saved</p>"; 

        }else{ 
            echo "<p class='error'> Could not store the quote because: " . mysqli_error($dbc) . "</p>";
            echo "<p> The query being run was: " . $query . "</p>"; 
        }
    
        mysqli_close($dbc); 

    }else{ 
        echo "<p class='error'>Enter a quote and a source</p>"; 
    }
}

?> 

<form action="add_quote.php" method="POST">
    <p><label>Quote <textarea name="quote" rows="5" cols="30"></textarea></label></p>
    <p><label>Source <input type="text" name="source"></label></p>
    <p><label>is this a favorite? <input type="checkbox" name="favorite" value="yes"></label></p>
    <p><input type="submit" name="submit" value="Add this Quote"></p>
</form>

<?php include('templates/footer.php'); ?> 

