<?php 

// function checks if user is admin 
function is_administrator($name = 'Carla', $value = 'Lafaurie') { 

    // checks for the cookie and checks its value 

    if(isset($_COOKIE[$name]) && ($_COOKIE[$name] == $value)){ 
        return true; 
    } else { 
        return false ; 
    }

}// ends admin function 

// connect variable 

 $dbc = mysqli_connect('localhost','root','root','Data-testing'); 
