<?php 

if(isset($_COOKIE['Carla'])) { 
    setcookie('Carla', FALSE, time() + 300); 

}

include('templates/header.php'); 

echo "<p>You are now logged out</p>"; 

include('templates/footer.php'); 


?>