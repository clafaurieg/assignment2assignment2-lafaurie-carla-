<?php 

$loggedin = false; 
$error = false; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') { 

    if(!empty($_POST['email']) && !empty($_POST['password'])) { 
        
    if((strtolower($_POST['email']) == 'clafaurie@ufl.edu') && ($_POST['password'] == 'password')) { 

        setcookie('Carla', 'Lafaurie', time()+3600); 

        $loggedin = true; 

    }else{ 
        $error = "<p>The submitted email address and password do not match</p>";
    } 
}else{ 
    $error = "<p>Please make sure you enter both an email and a password</p>"; 
}

} 

include('templates/header.php'); 

if($error){ 
    echo "<p class='error'>$error</p>";
}

if($loggedin) { 
    echo"<p>You are now logged in!</p>"; 
}else{ 
    echo '<h2>Login Form</h2>
<form action="login.php" method="post">
<p><label>Email Address <input type="email" name="email"></label></p>
<p><label>Password <input type="password" name="password"></label></p>
<p><input type="submit" name="submit" value="login"></p>
</form>'; 
    
}

include('templates/footer.php'); 

